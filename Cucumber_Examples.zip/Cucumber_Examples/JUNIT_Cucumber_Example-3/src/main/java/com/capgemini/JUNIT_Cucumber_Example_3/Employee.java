package com.capgemini.JUNIT_Cucumber_Example_3;

public class Employee {
	private int id;
	private String user;
	private float salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	/**
	 * @param id
	 * @param user
	 * @param salary
	 */
	public Employee(int id, String user, float salary) {
		super();
		this.id = id;
		this.user = user;
		this.salary = salary;
	}
 
	// constructor, getter, setter ommitted
}
